import 'package:flutter/material.dart';

class NewsPage extends StatelessWidget {
  final List<NewsItem> newsList = [
    NewsItem(
      title: 'Malaysia‘s Refill Store On Wheel Is Here ',
      description: 'Oh Sok Peng has started Malaysia’s first zero waste store',
      imageUrl: 'assets/images/n1.jpg',
    ),
    NewsItem(
      title: 'Watsons launches refill station in Malaysia',
      description: 'The station, located in Sunway Pyramid, offers six eco-refills for bestselling products',
      imageUrl: 'assets/images/n2.jpg',
    ),
    NewsItem(
      title: 'The Body Shop launches Refill Station',
      description: 'Skin and body care brand, The Body Shop Malaysia has launched its first refill station',
      imageUrl: 'assets/images/n3.jpg',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('News',style: TextStyle(
          fontWeight: FontWeight.w800,
          fontSize: 18.0,
          fontFamily: 'Poppins',
          color : Colors.white,
        ),),
        backgroundColor: Color(0XFF50c2c8),
      ),
      body: ListView.builder(
        itemCount: newsList.length,
        itemBuilder: (context, index) {
          return Container(
            decoration: BoxDecoration(
              color: Color(0xffc4e2f2),
              borderRadius: BorderRadius.circular(10.0),
            ),
            margin: EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
            child: ListTile(
              leading: CircleAvatar(backgroundImage: AssetImage(newsList[index].imageUrl)),
              title: Text(newsList[index].title,
                style: TextStyle(
                  fontWeight: FontWeight.w800,
                  fontSize: 15.0,
                  fontFamily: 'Poppins',
                  color : Colors.black,
                ),),
              subtitle: Text(newsList[index].description,
                style: TextStyle(
                fontSize: 13.0,
                fontFamily: 'Poppins',
                color : Colors.blueGrey,
              ),),
            ),
          );
        },
      ),
    );
  }
}

class NewsItem {
  final String title;
  final String description;
  final String imageUrl;

  NewsItem({required this.title, required this.description, required this.imageUrl});
}
