import 'package:flutter/material.dart';
import 'package:refillme/dashboard.dart';
import 'package:refillme/profile.dart';
import 'package:refillme/News.dart';
import 'package:refillme/leaderboard.dart';

class BottomNavBar extends StatefulWidget {
  @override
  _bottomNavBar createState() => _bottomNavBar();
}

class _bottomNavBar extends State {
  int _selectedIndex = 0;

  static final List _widgetOptions = [
    //Dashboard(),
    Dashboard(),
    NewsPage(),
    LeaderboardPage(),
    ProfilePage(),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: _widgetOptions.elementAt(_selectedIndex),
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.newspaper),
            label: 'News',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.bar_chart),
            label: 'Leaderboard',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Profile',
          ),
        ],
        currentIndex: _selectedIndex,
        unselectedItemColor: Colors.grey,
        selectedItemColor: Color(0XFF50c2c8),
        onTap: _onItemTapped,
      ),
    );
  }
}