import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';

import 'checkout.dart';

class Cart extends StatelessWidget {
  const Cart({super.key});


  @override
  Widget build(BuildContext context){
    double height = MediaQuery.of(context).size.height;
    double width = MediaQuery.of(context).size.width;


    return Scaffold(
      backgroundColor: Colors.grey.shade100,

      appBar: AppBar(
        backgroundColor: const Color(0XFF50c2c8),
        title: const Text(
          "Cart",
          style: TextStyle(
            // fontFamily: "Caveat",
            fontWeight: FontWeight.w800,
            fontSize: 18.0,
            fontFamily: 'Poppins',
            color : Colors.white,
          ),
        ),
      ),

      body: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            height: 100,
            child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Image.asset(
                    'assets/images/liquid.png',
                    fit: BoxFit.cover,
                  ),

                  Column(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: const [
                      Text(
                        'Laundry Liquid',
                        style: TextStyle(
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                        ),
                      ),
                      Text(
                        '2 kg',
                        style: TextStyle(
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                        ),
                      ),
                      Text(
                        'RM6 / 1 kg',
                        style: TextStyle(
                          fontFamily: 'Poppins',
                          color: Color(0XFF50c2c8),
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(width: 10),

                  minusbtn(),
                  const SizedBox(width: 10),
                  const Text(
                    '1',
                    style: TextStyle(
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.bold,
                      fontSize: 14,
                    ),
                  ),
                  const SizedBox(width: 10),
                  plusbtn(),
                ]
            ),
          ),

          Expanded(
            child: Align(
              alignment: FractionalOffset.bottomCenter,
              child: Container(
                padding: const EdgeInsets.all(10),
                width: MediaQuery.of(context).size.width,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30.0),
                    ),
                    backgroundColor: const Color(0XFF50c2c8),
                  ),
                  child: const Text(
                    'Checkout',
                    style: TextStyle(
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  onPressed: () {
                    Navigator.push(context, MaterialPageRoute(builder: (context) => const Checkout()),);
                  },
                )
              ),
            ),
          ),

        ],
      ),


    );
  }
}

class minusbtn extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 40.0,
      height: 40.0,
      decoration: const BoxDecoration(
        shape: BoxShape.circle,
        color: Color(0xFFC6C2C1),
        boxShadow: [
          BoxShadow(
            color: Colors.black12,
            offset: Offset(2.0, 2.0),
            blurRadius: 4.0,
          ),
        ],
      ),
      child: Center(
        child: IconButton(
          icon: const Icon(
            Icons.remove,
            color: Colors.black,
            size: 25.0,
          ),
          onPressed: () {
            // Do something here
          },
        ),
      ),
    );
  }
}

class plusbtn extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 40.0,
      height: 40.0,
      decoration: const BoxDecoration(
        shape: BoxShape.circle,
        color: Color(0XFF50c2c8),
        boxShadow: [
          BoxShadow(
            color: Colors.black12,
            offset: Offset(2.0, 2.0),
            blurRadius: 4.0,
          ),
        ],
      ),
      child: Center(
        child: IconButton(
          icon: const Icon(
            Icons.add,
            color: Colors.white,
            size: 25.0,
          ),
          onPressed: () {
            // Do something here
          },
        ),
      ),
    );
  }
}

