import 'package:flutter/material.dart';

class CenterListPage extends StatelessWidget {
  final List<CenterItem> centerList = [
    CenterItem(
      title: 'KitaRefill BYOB Detergent Bulk Store',
      description: '15, Jalan SS 20/11, Damansara Kim, 47400 Petaling Jaya, Selangor',
      imageUrl: 'https://picsum.photos/200/300?random=1',

    ),
    CenterItem(
      title: 'Wowo Refill Store',
      description: '63, Jalan Bunga Tanjung 8b, Ampang, Kuala Lumpur',
      imageUrl: 'https://picsum.photos/200/300?random=2',
    ),
    CenterItem(
      title: 'Watsons Refill Station',
      description: 'Lot LG 2.67 & LG 2.68 LG2, Lot LG 2.67 & 2.68, LG2, 3, Jalan PJS 11/15, Bandar Sunway, 46150 Petaling Jaya, Selangor',
      imageUrl: 'https://picsum.photos/200/300?random=3',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Center List',
          style: TextStyle(
            fontWeight: FontWeight.w800,
            fontSize: 18.0,
            fontFamily: 'Poppins',
            color : Colors.white,
          ),
        ),
        backgroundColor: Color(0XFF50c2c8),
      ),
      body: ListView.builder(
        itemCount: centerList.length,
        itemBuilder: (context, index) {
          return Card(
            margin: EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
            child: ListTile(
              title: Text(
                centerList[index].title,
                style: TextStyle(
                  fontWeight: FontWeight.w800,
                  fontSize: 16.0,
                  fontFamily: 'Poppins',
                  color : Colors.black,
                ),
              ),
              subtitle: Text(
                centerList[index].description,
                style: TextStyle(
                  color: Color(0XFF50c2c8),
                  fontSize: 12.0,
                  fontFamily: 'Poppins',
                ),
              ),
              trailing: Icon(Icons.favorite,color: Colors.pink),
            ),
          );
        },
      ),
    );
  }
}

class CenterItem {
  final String title;
  final String description;
  final String imageUrl;

  CenterItem({required this.title, required this.description, required this.imageUrl});
}
