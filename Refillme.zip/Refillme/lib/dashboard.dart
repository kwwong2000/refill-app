import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:refillme/locator.dart';
import 'package:refillme/pickup.dart';
import 'package:refillme/productlist.dart';
import 'package:refillme/rewards.dart';
import 'package:refillme/bottom_nav_bar.dart';
import 'package:refillme/trackOrder.dart';

class Dashboard extends StatelessWidget {
  const Dashboard({super.key});

  @override
  Widget build(BuildContext context){
    double height = MediaQuery.of(context).size.height;
    double width = MediaQuery.of(context).size.width;
    return Scaffold(
        backgroundColor: const Color(0XFF50c2c8),

        body: ListView(
            children: [
              const SizedBox(height: 25),

              Center(
                //welcome back susan
                child: Container(
                  margin: EdgeInsets.all(10),
                  height: 70,
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.all(Radius.circular(10)),
                  ),

                  child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: <Widget>[
                        IconButton(
                          icon: Image.asset('assets/images/profile.png'),
                          iconSize: 100,
                          onPressed: (){
                            //Navigator.push(context, MaterialPageRoute(builder: (context) => pubgPage()),);
                          },

                        ),
                        Expanded(
                            child: Container(
                                padding: const EdgeInsets.all(2),
                                child: const Align(
                                  alignment: Alignment.centerLeft,
                                  child: Text(
                                      'Welcome back, Susan',
                                      style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        fontSize: 18,
                                        fontFamily: 'Poppins',
                                      )
                                  ),
                                ),
                            )
                        )
                      ]
                  ),

                ),
              ),

              SizedBox(height: 10),

              //progress
              Center(
                child: Container(
                  decoration: BoxDecoration(
                    color: const Color(0XFFf4f5f9),
                    borderRadius: BorderRadius.vertical(
                        top: Radius.elliptical(
                            MediaQuery.of(context).size.width, 100.0)),
                  ),
                  height: MediaQuery.of(context).size.height - MediaQuery.of(context).size.height*0.25,
                  width: width,

                    child: Column(
                      children: [
                        const SizedBox(height: 10),
                        const Text(
                          'Progress',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 18,
                            fontFamily: 'Poppins',
                          ),
                        ),
                       // const SizedBox(height: 10),
                        Image.asset(
                          'assets/images/progress1.png',
                          scale: 2.3,
                        ),

                        const SizedBox(height: 10),

                        const Text(
                          'Services',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 18,
                            fontFamily: 'Poppins',
                          ),
                        ),
                        Column(
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                productList(),
                                schedule(),
                                locator(),
                              ],
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                tracking(),
                                rewards(),
                                Container(
                                  margin: const EdgeInsets.all(5),
                                  padding: const EdgeInsets.all(5),
                                  width: 80,
                                  height: 70,
                                )
                              ],
                            )
                          ],
                        ),




                      ],
                    ),

                ),
              ),


            ]
        ),
/*
      BottomNavBar(),

 */
    );
  }
}

class productList extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Container(
      margin: const EdgeInsets.all(5),
      padding: const EdgeInsets.all(5),
      child: ElevatedButton(
        onPressed: () => {
          Navigator.push(context, MaterialPageRoute(builder: (context) => const ProductList()),),
        },
         style: TextButton.styleFrom(
           fixedSize: const Size(70, 70),
           foregroundColor: Colors.white,
           backgroundColor: const Color(0XFF50c2c8),
           padding: const EdgeInsets.all(5),
           shape: RoundedRectangleBorder(
             borderRadius: BorderRadius.circular(10),
           )
        ),

        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: const <Widget>[
            Icon(Icons.list_alt),
            Text(
              "Product list",
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 12,
              ),
            ),
          ],
        ),
      ),
    );
  }

}

class schedule extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Container(
      margin: const EdgeInsets.all(5),
      padding: const EdgeInsets.all(5),
      child: ElevatedButton(
        onPressed: () => {
          Navigator.push(context, MaterialPageRoute(builder: (context) => const ScheduledPickUp()),),
        },
        style: TextButton.styleFrom(
            fixedSize: const Size(70, 70),
            foregroundColor: Colors.white,
            backgroundColor: const Color(0XFF50c2c8),
            padding: const EdgeInsets.all(5),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            )
        ),

        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: const <Widget>[
            Icon(Icons.calendar_month),
            Text(
              "Schedule pick-up",
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 12,
              ),
            ),
          ],
        ),
      ),
    );
  }

}

class locator extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Container(
      margin: const EdgeInsets.all(5),
      padding: const EdgeInsets.all(5),
      child: ElevatedButton(
        onPressed: () => {
          Navigator.push(context, MaterialPageRoute(builder: (context) => LocatorPage()),),
        },
        style: TextButton.styleFrom(
            fixedSize: const Size(70, 70),
            foregroundColor: Colors.white,
            backgroundColor: const Color(0XFF50c2c8),
            padding: const EdgeInsets.all(5),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            )
        ),

        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: const <Widget>[
            Icon(Icons.pin_drop),
            Text(
              "Center Locator",
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 12,
              ),
            ),
          ],
        ),
      ),
    );
  }

}

class tracking extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Container(
      margin: const EdgeInsets.all(5),
      padding: const EdgeInsets.all(5),
      child: ElevatedButton(
        onPressed: () => {
          Navigator.push(context, MaterialPageRoute(builder: (context) => ordersPage()),),
        },
        style: TextButton.styleFrom(
            fixedSize: const Size(70, 70),
            foregroundColor: Colors.white,
            backgroundColor: const Color(0XFF50c2c8),
            padding: const EdgeInsets.all(5),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            )
        ),

        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: const <Widget>[
            Icon(Icons.track_changes),
            Text(
              "Tracking",
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 12,
              ),
            ),
          ],
        ),
      ),
    );
  }

}

class rewards extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Container(
      margin: const EdgeInsets.all(5),
      padding: const EdgeInsets.all(5),
      child: ElevatedButton(
        onPressed: () => {
        Navigator.push(context, MaterialPageRoute(builder: (context) => Rewards()),),
        },
        style: TextButton.styleFrom(
            fixedSize: const Size(70, 70),
            foregroundColor: Colors.white,
            backgroundColor: const Color(0XFF50c2c8),
            padding: const EdgeInsets.all(5),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            )
        ),

        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: const <Widget>[
            Icon(Icons.redeem),
            Text(
              "Rewards",
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 12,
              ),
            ),
          ],
        ),
      ),
    );
  }

}