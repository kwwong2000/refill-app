import 'package:flutter/material.dart';
import 'package:refillme/login.dart';
import 'package:refillme/register.dart';

class HomePage extends StatelessWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(color: Colors.white),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Expanded(
              flex: 3,
              child: ClipPath(
                clipper: WaveClipper(),
                child: Container(
                  color: Color(0XFF50c2c8),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Image.asset(
                        'assets/images/refillme.png',
                        width: 100,
                        height: 100,
                        fit: BoxFit.cover,
                      ),
                      const Text(
                        'Refillme',
                        style: TextStyle(
                          fontSize: 40.0,
                          color: Colors.white,
                          fontFamily: 'Ramaraja',
                        ),
                      ), //title
                    ],
                  ),
                ),
              ),
            ),
            Expanded(
              flex: 2,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Text(
                      'Welcome',
                      style: TextStyle(
                          color: Color(0XFF50c2c8),
                          fontWeight: FontWeight.bold,
                          fontSize: 25,
                        fontFamily: 'Poppins',
                      ),
                  ),
                  const SizedBox(height: 10.0),
                  const Text(
                    'Together, we can save the Earth',
                    style: TextStyle(
                      fontFamily: 'Poppins',
                      color: Color(0XFF50c2c8),
                    ),
                  ),
                  SizedBox(height: 40.0),
                  SizedBox(
                    width: MediaQuery.of(context).size.width - 100,
                    height: 40,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.push(context, MaterialPageRoute(builder: (context) => LoginPage()),);
                      },
                      style: ElevatedButton.styleFrom(
                        foregroundColor: Colors.white,
                        backgroundColor: Color(0XFF50c2c8),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(30.0),
                        ),
                      ),
                      child: const Text(
                        'Log In',
                          style: TextStyle(
                            fontFamily: 'Poppins',
                            fontWeight: FontWeight.bold,
                          )
                      ),
                    ),
                  ),

                  const SizedBox(height: 20.0),
                  SizedBox(
                    height: 40,
                    width: MediaQuery.of(context).size.width - 100,
                    child: OutlinedButton(
                      onPressed: () {
                        Navigator.push(context, MaterialPageRoute(builder: (context) => RegisterPage()),);
                      },
                      style: OutlinedButton.styleFrom(
                        foregroundColor: Color(0XFF50c2c8),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(30.0),
                        ),
                        side: BorderSide(color: Color(0XFF50c2c8)),
                      ),
                      child: const Text(
                        'Register',
                        style: TextStyle(
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),

                ],
              ),
            ),
            SizedBox(height: 20.0),
          ],
        ),
      ),
    );
  }
}

class WaveClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    Path path = Path();
    path.lineTo(0, size.height * 0.8);
    path.quadraticBezierTo(size.width * 0.25, size.height * 0.9, size.width * 0.4, size.height * 0.8);
    path.quadraticBezierTo(size.width * 0.55, size.height * 0.7, size.width * 0.7, size.height * 0.8);
    path.quadraticBezierTo(size.width * 0.85, size.height * 0.9, size.width, size.height * 0.8);
    path.lineTo(size.width, 0);
    path.close();
    return path;
  }

  @override
  bool shouldReclip(WaveClipper oldClipper) => false;
}





