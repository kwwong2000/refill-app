import 'package:flutter/material.dart';

class LeaderboardPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Leaderboard',
          style: TextStyle(
          fontWeight: FontWeight.w800,
          fontSize: 18.0,
          fontFamily: 'Poppins',
          color : Colors.white,
        ),),
        backgroundColor: const Color(0XFF50c2c8),
      ),
      backgroundColor: const Color(0XFF50c2c8),
      body: Column(
        children: [
          const SizedBox(height: 10),
          Container(
            height: 30, // set the height to 50
            width: 250,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(30),
              color: Colors.white,
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _buildSection('Weekly'),
                _buildSection('Monthly'),
                _buildSection('Overall', isActive: true),
              ],
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const SizedBox(width: 16),
              _buildLeaderboardPlace(context, 2, name: 'John Doe',
                  score: 168, imgUrl:'assets/images/p1.jpg'),
              _buildLeaderboardPlace(context, 1, large: true, name: 'George Arthur',
                  score: 200, imgUrl:'assets/images/p2.png'),
              _buildLeaderboardPlace(context, 3, name: 'Bob Smith',
                  score: 125, imgUrl:'assets/images/p3.png'),
              const SizedBox(width: 16),
            ],
          ),
          Card(
            margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
            elevation: 4,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
              //set border radius more than 50% of height and width to make circle
            ),
            child: Column(
              children: const [
                ListTile(
                  leading: CircleAvatar(
                    backgroundColor: Color(0xFF50c2c8),
                    child: Text(
                      '4',
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                          fontFamily: 'Poppins'
                      ),
                    ),
                  ),
                  title: Text(
                    'Olivia Hen',
                    style: TextStyle(fontWeight: FontWeight.bold,
                      fontSize: 15.0,
                      fontFamily: 'Poppins',
                      color : Colors.black,
                    ),
                  ),
                  subtitle: Text('Score: 96',
                    style: TextStyle(
                      fontSize: 13.0,
                      fontFamily: 'Poppins'
                    ),
                  ),
                  trailing: CircleAvatar(
                    backgroundImage: AssetImage(
                      'assets/images/p4.jpg',
                    ),
                  ),
                ),
                ListTile(
                  leading: CircleAvatar(
                    backgroundColor: Color(0xFF50c2c8),
                    child: Text(
                      '5',
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                          fontFamily: 'Poppins'
                      ),
                    ),
                  ),
                  title: Text(
                    'Amelia Mendes',
                    style: TextStyle(fontWeight: FontWeight.bold,
                      fontSize: 15.0,
                      fontFamily: 'Poppins',
                      color : Colors.black,
                    ),
                  ),
                  subtitle: Text('Score: 75',style: TextStyle(
                      fontSize: 13.0,
                      fontFamily: 'Poppins'
                  ),),
                  trailing: CircleAvatar(
                    backgroundImage: AssetImage(
                      'assets/images/p5.jpg',
                    ),
                  ),
                ),
                ListTile(
                  leading: CircleAvatar(
                    backgroundColor: Color(0xFF50c2c8),
                    child: Text(
                      '6',
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                          fontFamily: 'Poppins'
                      ),
                    ),
                  ),
                  title: Text(
                    'Noah Smith',
                    style: TextStyle(fontWeight: FontWeight.bold,
                      fontSize: 15.0,
                      fontFamily: 'Poppins',
                      color : Colors.black,
                    ),
                  ),
                  subtitle: Text('Score: 50',style: TextStyle(
                      fontSize: 13.0,
                      fontFamily: 'Poppins'
                  ),),
                  trailing: CircleAvatar(
                    backgroundImage: AssetImage(
                      'assets/images/p6.jpg',
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLeaderboardPlace(BuildContext context, int place, {bool large = false,
    required String name, required int score,
    required String imgUrl
  }) {
    double avatarSize = large ? 35.0 : 28.0;
    double nameFontSize = large ? 16.0 : 12.0;
    double scoreFontSize = large ? 14.0 : 10.0;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: const BoxDecoration(
              image: DecorationImage(
                image: AssetImage(
                  'assets/images/crown.png',
                ),
              ),
            ),
            child: Center(
              child: Text(
                '$place',
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Poppins',
                ),
              ),
            ),
          ),
          CircleAvatar(
            radius: avatarSize,
            backgroundImage: AssetImage(
              imgUrl,
            ),
          ),
          SizedBox(height: 8),
          Text(
            name,
            style: TextStyle(
              fontSize: nameFontSize,
              fontWeight: FontWeight.bold,
              color: Colors.white,
              fontFamily: 'Poppins'
            ),
          ),
          Text(
            'Score: $score',
            style: TextStyle(
              fontSize: scoreFontSize,
              color: Colors.white,
              fontFamily: 'Poppins'
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSection(String title, {bool isActive = false}) {
    final color = isActive ? const Color(0xFF92D4DE) : Colors.transparent;
    return Expanded(
      child: Container(
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(30),
        ),
        child: Center(
          child: Text(
            title,
            style: const TextStyle(
              color: Colors.black,
              fontWeight: FontWeight.bold,
                fontFamily: 'Poppins'
            ),
          ),
        ),
      ),
    );
  }
}
