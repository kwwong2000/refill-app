import 'package:flutter/material.dart';

import 'centerList.dart';

class LocatorPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Center Locator',
          style: TextStyle(
            fontWeight: FontWeight.w800,
            fontSize: 18.0,
            fontFamily: 'Poppins',
            color : Colors.white,
          ),),
        backgroundColor: Color(0XFF50c2c8),
      ),
      body: ListView(
        children: [
          SizedBox(height: 10),
          Row(
            children: [
              SizedBox(width: 10),
              const CircleAvatar(
                child: Icon(Icons.shopping_bag, color: Colors.white),
                backgroundColor: Color(0XFF50c2c8),
              ),
              SizedBox(width: 10),
              Expanded(
                child:Container(
                  height: 40,
                  alignment: Alignment.center,
                  child: TextField(
                    decoration: InputDecoration(
                      prefixIcon: const Icon(Icons.search),
                      hintText: 'Product name',
                      contentPadding: const EdgeInsets.fromLTRB(10, 0, 0, 0),
                      hintStyle: TextStyle(fontFamily: 'Poppins', fontSize: 12),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(25.0),

                      ),
                    ),
                  ),
                ),

              ),
              SizedBox(width: 10),
            ],
          ),
          SizedBox(height: 10),
          Row(
            children: [
              SizedBox(width: 10),
              CircleAvatar(
                child: Icon(Icons.location_on, color: Colors.white),
                backgroundColor: Color(0XFF50c2c8),
              ),
              SizedBox(width: 10),
              Expanded(
                child: Container(
                  height: 40,
                  alignment: Alignment.center,
                  child: TextField(
                    decoration: InputDecoration(
                      prefixIcon: const Icon(Icons.search),
                      hintText: 'Search for location',
                      contentPadding: const EdgeInsets.fromLTRB(10, 0, 0, 0),
                      hintStyle: TextStyle(fontFamily: 'Poppins', fontSize: 12),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(25.0),

                      ),
                    ),
                  ),
                ),
              ),
              SizedBox(width: 10),
            ],
          ),
          Image.asset(
            'assets/images/img.png',
            scale: 2,
              ),
          Container(
            padding: const EdgeInsets.fromLTRB(10, 0, 10, 10),
            width: MediaQuery.of(context).size.width - 100,
            height: 50,
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                primary: Color(0XFF50c2c8),
                onPrimary: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30.0),
                ),
              ),
              onPressed: () {

              },
              child: Text('Search Nearby Refill Center', style: TextStyle(fontFamily: 'Poppins')),
            ),
          ),
          Container(
            padding: const EdgeInsets.fromLTRB(10, 0, 10, 10),
            height: 50,
            width: MediaQuery.of(context).size.width - 100,
            child: OutlinedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => CenterListPage()),
                );
              },
              child: Text('List of Refill Center'),
              style: OutlinedButton.styleFrom(
                foregroundColor: Color(0XFF50c2c8),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30.0),
                ),
                side: BorderSide(color: Color(0XFF50c2c8)),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
