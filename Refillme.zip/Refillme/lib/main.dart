import 'package:flutter/material.dart';
import 'package:refillme/home.dart';
import 'package:refillme/profile.dart';
import 'bottom_nav_bar.dart';
import 'dashboard.dart';

void main() {
  runApp(MaterialApp(
      home: MyApp()),
  );
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Refillme',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(primaryColor: const Color(0XFF50c2c8),),
      home: const HomePage(),
    );
  }
}
