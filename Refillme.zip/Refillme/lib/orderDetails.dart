import 'package:flutter/material.dart';

class detailsPage extends StatelessWidget {
  final List<OrdersItem> ordersList = [
    OrdersItem(
      title: 'Order Placed ',
      description: '14 March 2023',
      imageUrl: 'assets/images/placed.png',
    ),
    OrdersItem(
      title: 'Order Shipped',
      description: '14 March 2023',
      imageUrl: 'assets/images/shipped.png',
    ),
    OrdersItem(
      title: 'Refilling',
      description: 'In Progress',
      imageUrl: 'assets/images/refilling.png',
    ),
    OrdersItem(
      title: 'Out For Delivery',
      description: 'Pending',
      imageUrl: 'assets/images/delivery.png',
    ),
    OrdersItem(
      title: 'Order Delivered',
      description: 'Pending',
      imageUrl: 'assets/images/delivered.png',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xfff4f5f9),
      appBar: AppBar(
        title: const Text('Order Details',
            style: TextStyle(
          fontWeight: FontWeight.w800,
          fontSize: 18.0,
          fontFamily: 'Poppins',
          color : Colors.white,
        )),
        backgroundColor: Color(0XFF50c2c8),
      ),
      body: Column(
        children: [
          Card(
            child: ListTile(
              leading: ClipRRect(
                borderRadius: BorderRadius.circular(8.0),
                child: Container(
                  width: 50.0,
                  height: 50.0,
                  decoration: BoxDecoration(
                    image: const DecorationImage(
                      image: AssetImage('assets/images/order.png'),
                      fit: BoxFit.cover,
                    ),
                    borderRadius: BorderRadius.circular(8.0),
                  ),
                ),
              ),
              title: const Padding(padding: EdgeInsets.only(left: 25.0),
                child: Text('Order #90897',
                  style: TextStyle(fontWeight: FontWeight.bold,fontFamily: 'Poppins'),
                ),
              ),
              subtitle: const Padding(padding: EdgeInsets.only(left: 25.0),
                child: Text('Place on 14 March 2023',
                    style: TextStyle(fontSize: 15, color: Colors.grey,fontFamily: 'Poppins')),
              ),

            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: ordersList.length,
              itemBuilder: (context, index) {
                final order = ordersList[index];
                return Column(
                  children: [
                    Container(
                      decoration: const BoxDecoration(
                        border: Border(
                          bottom: BorderSide(
                            color: Colors.grey,
                            width: 0.5,
                          ),
                        ),
                      ),
                      child: ListTile(
                        tileColor: Colors.transparent,
                        leading: ClipRRect(
                          borderRadius: BorderRadius.circular(8.0),
                          child: Container(
                            width: 50.0,
                            height: 50.0,
                            decoration: BoxDecoration(
                              image: DecorationImage(
                                image: AssetImage(order.imageUrl),
                                fit: BoxFit.cover,
                              ),
                              borderRadius: BorderRadius.circular(8.0),
                            ),
                          ),
                        ),
                        title: Padding(
                          padding: const EdgeInsets.only(left: 25.0),
                          child: Text(
                            order.title,
                            style: const TextStyle(fontWeight: FontWeight.bold,fontFamily: 'Poppins'),
                          ),
                        ),
                        subtitle: Padding(
                          padding: const EdgeInsets.only(left: 25.0),
                          child: Text(
                            order.description,
                            style: const TextStyle(color: Colors.grey, fontSize: 15,fontFamily: 'Poppins'),
                          ),
                        ),
                      ),
                    ),
                  ],
                );
              },
            ),
          ),

        ],
      ),
    );
  }
}

class OrdersItem {
  final String title;
  final String description;
  final String imageUrl;

  OrdersItem(
      {required this.title, required this.description, required this.imageUrl});
}
