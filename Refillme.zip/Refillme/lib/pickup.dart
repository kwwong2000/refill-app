import 'package:flutter/material.dart';

import 'cart.dart';

class ScheduledPickUp extends StatelessWidget {
  const ScheduledPickUp({super.key});

  @override
  Widget build(BuildContext context){

    return Scaffold(
      backgroundColor: const Color(0XFFf4f5f9),

      appBar: AppBar(
        backgroundColor: const Color(0XFF50c2c8),
        title: const Text(
          "Scheduled Pick-Up",
          style: TextStyle(
            // fontFamily: "Caveat",
            fontWeight: FontWeight.w800,
            fontSize: 18.0,
            fontFamily: 'Poppins',
            color : Colors.white,
          ),),
      ),

      body: Center(
        child: ListView(
            padding: const EdgeInsets.all(10),
            children: <Widget>[
              const SizedBox(height: 10),
              Container(
                height: 40,
                alignment: Alignment.center,
                child: TextField(
                  decoration: InputDecoration(
                    prefixIcon: const Icon(Icons.search),
                    hintText: 'Search',
                    contentPadding: const EdgeInsets.fromLTRB(10, 0, 0, 0),
                    hintStyle: const TextStyle(fontFamily: 'Poppins', fontSize: 14),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(25.0),

                    ),
                  ),
                ),
              ),

              const SizedBox(height: 10),

              const Text(
                'Categories',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Poppins',
                ),
              ),

              const SizedBox(height: 10),

              Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: const [
                      liquid(),
                      powder(),
                    ],
                  ),

                  const SizedBox(height: 20),

                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: const [
                      softener(),
                      SizedBox(
                        height: 180,
                        width: 130,
                      ),
                    ],
                  ),
                ],
              ),
            ]
        ),

      ),
    );
  }
}

class liquid extends StatelessWidget{
  const liquid({super.key});

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Container(
      padding: const EdgeInsets.all(2),
      height: 180,
      width: 130,
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.all(Radius.circular(20.0)),
      ),
      child: Column(
        children: [
          Image.asset(
            'assets/images/liquid.png',
            scale: 2.0,
          ),

          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Column(
                children:const [
                  Text(
                    'Laundry',
                    textAlign: TextAlign.right,
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Poppins',
                      fontSize: 14,
                    ),
                  ),
                  Text(
                    'Liquid',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Poppins',
                      fontSize: 14,
                    ),
                  ),
                  Text(
                    'RM6 / 1kg',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Color(0XFF50c2c8),
                      fontFamily: 'Poppins',
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
              FloatingActionButton.small(
                onPressed: (){
                  showDialog(
                    context: context,
                    builder: (BuildContext context){
                      return AlertDialog(
                        content: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Column(
                              children: [
                                const Text(
                                  'Weight',
                                  style: TextStyle(
                                    fontFamily: 'Poppins',
                                    fontWeight: FontWeight.bold,
                                    fontSize: 14,
                                  ),
                                ),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                  children: const [
                                    btn1(),
                                    SizedBox(width: 10),
                                    btn2(),
                                    SizedBox(width: 10),
                                    btn3(),
                                  ]
                                ),
                                const SizedBox(height: 20),
                                const Text(
                                  'Quantity',
                                  style: TextStyle(
                                    fontFamily: 'Poppins',
                                    fontWeight: FontWeight.bold,
                                    fontSize: 14,
                                  ),
                                ),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                  children: const [
                                    minusbtn(),
                                    SizedBox(width: 10),
                                    Text(
                                      '1',
                                      style: TextStyle(
                                        fontFamily: 'Poppins',
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    SizedBox(width: 10),
                                    plusbtn(),
                                  ]
                                ),
                                const SizedBox(height: 20),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [
                                    const Flexible(
                                      child: Text(
                                        "Please take note of your container's capacity to prevent waste.",
                                        style: TextStyle(
                                          fontFamily: 'Poppins',
                                          fontSize: 10,
                                        ),
                                      ),
                                    ),
                                    ElevatedButton(
                                      onPressed: (){
                                        Navigator.push(context, MaterialPageRoute(builder: (context) => const Cart()),);
                                      },
                                      style: ElevatedButton.styleFrom(
                                        foregroundColor: const Color(0XFF50c2c8),
                                        backgroundColor: Colors.white,
                                        shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(20.0),
                                          side: const BorderSide(color: Color(0XFF50c2c8), width: 2,),
                                        ),
                                      ),
                                      child: const Text(
                                        'Confirm',
                                        style: TextStyle(
                                          fontFamily: 'Poppins',
                                          fontWeight: FontWeight.bold,
                                          fontSize: 14,
                                        ),
                                      ),
                                    ),
                                  ],
                                )
                              ],
                            ),
                          ]
                        ),

                      );
                    },
                  );
                },
                backgroundColor: const Color(0XFF50c2c8),
                child: const Icon(
                  Icons.add,
                  color: Colors.white,
                ),
              ),

            ],
          ),

        ],
      ),
    );
  }

}

class powder extends StatelessWidget{
  const powder({super.key});

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Container(
      height: 180,
      width: 130,
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.all(Radius.circular(20.0)),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Image.asset(
            'assets/images/powder.png',
            scale: 2.4,
          ),
          const SizedBox(height: 10),

          Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Column(
                    children: const [
                      Text(
                        'Laundry',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Poppins',
                          fontSize: 14,
                        ),
                      ),
                      Text(
                        'Powder',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Poppins',
                          fontSize: 14,
                        ),
                      ),
                      Text(
                        'RM6.50 / 1kg',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: Color(0XFF50c2c8),
                          fontFamily: 'Poppins',
                          fontSize: 12,
                        ),
                      ),
                    ],
                ),
                FloatingActionButton.small(
                  onPressed: (){},
                  backgroundColor: const Color(0XFF50c2c8),
                  child: const Icon(
                    Icons.add,
                    color: Colors.white,
                  ),
                ),
              ],
          ),
        ],
      ),
    );
  }
}

class softener extends StatelessWidget{
  const softener({super.key});

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Container(
      height: 180,
      width: 130,
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.all(Radius.circular(20.0)),
      ),
      child: Column(
        children: [
          Image.asset(
            'assets/images/softener.png',
            scale: 2.1,
          ),

          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Column(
                children: const [
                  Text(
                    'Softener',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Poppins',
                      fontSize: 14,
                    ),
                  ),
                  Text(
                    'RM5 / 1kg',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Color(0XFF50c2c8),
                      fontFamily: 'Poppins',
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
              FloatingActionButton.small(
                onPressed: (){},
                backgroundColor: const Color(0XFF50c2c8),
                child: const Icon(
                  Icons.add,
                  color: Colors.white,
                ),
              ),

            ],
          )

        ],
      ),
    );
  }
}

class btn1 extends StatelessWidget{
  const btn1({super.key});

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      onPressed: (){},
      style: ElevatedButton.styleFrom(
        foregroundColor: const Color(0XFF50c2c8),
        backgroundColor: Colors.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20.0),
          side: const BorderSide(color: Color(0XFF50c2c8), width: 2,),
        ),
      ),
      child: const Text(
        '1 kg',
        style: TextStyle(
          fontFamily: 'Poppins',
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }
}

class btn2 extends StatelessWidget{
  const btn2({super.key});

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      onPressed: (){},
      style: ElevatedButton.styleFrom(
        foregroundColor: Colors.white,
        backgroundColor: const Color(0XFF50c2c8),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20.0),
          side: const BorderSide(color: Color(0XFF50c2c8), width: 2,),
        ),
      ),
      child: const Text(
        '2 kg',
        style: TextStyle(
          fontFamily: 'Poppins',
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }
}

class btn3 extends StatelessWidget{
  const btn3({super.key});

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      onPressed: (){},
      style: ElevatedButton.styleFrom(
        foregroundColor: const Color(0XFF50c2c8),
        backgroundColor: Colors.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20.0),
          side: const BorderSide(color: Color(0XFF50c2c8), width: 2,),
        ),
      ),
      child: const Text(
        '3 kg',
        style: TextStyle(
          fontFamily: 'Poppins',
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }
}

class minusbtn extends StatelessWidget{
  const minusbtn({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 40.0,
      height: 40.0,
      decoration: const BoxDecoration(
        shape: BoxShape.circle,
        color: Color(0XFF50c2c8),
        boxShadow: [
          BoxShadow(
            color: Colors.black12,
            offset: Offset(2.0, 2.0),
            blurRadius: 4.0,
          ),
        ],
      ),
      child: Center(
        child: IconButton(
          icon: const Icon(
            Icons.remove,
            color: Colors.white,
            size: 25.0,
          ),
          onPressed: () {
            // Do something here
          },
        ),
      ),
    );
  }
}

class plusbtn extends StatelessWidget{
  const plusbtn({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 40.0,
      height: 40.0,
      decoration: const BoxDecoration(
        shape: BoxShape.circle,
        color: Color(0XFF50c2c8),
        boxShadow: [
          BoxShadow(
            color: Colors.black12,
            offset: Offset(2.0, 2.0),
            blurRadius: 4.0,
          ),
        ],
      ),
      child: Center(
        child: IconButton(
          icon: const Icon(
            Icons.add,
            color: Colors.white,
            size: 25.0,
          ),
          onPressed: () {
            // Do something here
          },
        ),
      ),
    );
  }
}

