import 'package:flutter/material.dart';

class ProductList extends StatelessWidget {
  const ProductList({super.key});

  @override
  Widget build(BuildContext context){

    return Scaffold(
      backgroundColor: Colors.grey.shade100,

      appBar: AppBar(
        backgroundColor: const Color(0XFF50c2c8),
        title: const Text(
          "Product List",
          style: TextStyle(
            // fontFamily: "Caveat",
            fontWeight: FontWeight.w800,
            fontSize: 18.0,
            fontFamily: 'Poppins',
            color : Colors.white,
          ),),
      ),

      body: Center(
        child: ListView(
          padding: const EdgeInsets.all(10),
          children: <Widget>[
            const SizedBox(height: 10),
            Container(
              height: 40,
              alignment: Alignment.center,
              child: TextField(
                decoration: InputDecoration(
                  prefixIcon: const Icon(Icons.search),
                  hintText: 'Search',
                  contentPadding: const EdgeInsets.fromLTRB(10, 0, 0, 0),
                  hintStyle: const TextStyle(fontFamily: 'Poppins', fontSize: 14),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(25.0),
                    
                  ),
                ),
              ),
            ),

            const SizedBox(height: 10),

            const Text(
              'Categories',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                fontFamily: 'Poppins',
              ),
            ),

            const SizedBox(height: 10),

            Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    liquid(),
                    powder(),
                  ],
                ),

                const SizedBox(height: 20),

                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    softener(),
                    Container(
                      height: 180,
                      width: 130,
                    ),
                  ],
                ),
              ],
            ),
          ]
        ),

      ),

    );
  }
}

class liquid extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Container(
      alignment: Alignment.center,
      height: 180,
      width: 130,
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.all(Radius.circular(20.0)),
      ),
      child: Column(
        children: [
          Image.asset(
            'assets/images/liquid.png',
            scale: 1.8,
          ),
          const Text(
            'Laundry Liquid',
            style: TextStyle(
              fontWeight: FontWeight.bold,
              fontFamily: 'Poppins',
              fontSize: 14,
            ),
          ),
          const Text(
            'RM6 / 1kg',
            style: TextStyle(
              fontWeight: FontWeight.bold,
              fontFamily: 'Poppins',
              fontSize: 14,
              color: Color(0XFF50c2c8),
            ),
          ),
        ],
      ),
    );
  }
}

class powder extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Container(
      height: 180,
      width: 130,
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.all(Radius.circular(20.0)),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Image.asset(
            'assets/images/powder.png',
            scale: 2.2,
          ),
          const SizedBox(height: 10),
          const Text(
            'Laundry Powder',
            style: TextStyle(
              fontWeight: FontWeight.bold,
              fontFamily: 'Poppins',
              fontSize: 14
            ),
          ),
          const Text(
            'RM6.50 / 1kg',
            style: TextStyle(
              fontWeight: FontWeight.bold,
              color: Color(0XFF50c2c8),
              fontFamily: 'Poppins',
              fontSize: 14,
            ),
          ),
        ],
      ),
    );
  }
}

class softener extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Container(
      height: 180,
      width: 130,
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.all(Radius.circular(20.0)),
      ),
      child: Column(
        children: [
          Image.asset(
            'assets/images/softener.png',
            scale: 1.9,
          ),
          const Text(
            'Softener',
            style: TextStyle(
              fontWeight: FontWeight.bold,
              fontFamily: 'Poppins',
              fontSize: 14,
            ),
          ),
          const Text(
            'RM5 / 1kg',
            style: TextStyle(
              fontWeight: FontWeight.bold,
              fontFamily: 'Poppins',
              color: Color(0XFF50c2c8),
              fontSize: 14,
            ),
          ),
        ],
      ),
    );
  }
}