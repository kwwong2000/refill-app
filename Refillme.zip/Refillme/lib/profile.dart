import 'package:flutter/material.dart';

import 'home.dart';

class ProfilePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Profile',
          style: TextStyle(
            fontWeight: FontWeight.w800,
            fontSize: 18.0,
            fontFamily: 'Poppins',
            color : Colors.white,
          ),
        ),
        backgroundColor: const Color(0XFF50c2c8),
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0XFF50c2c8),Colors.white,],
          ),
        ),

        child: ListView(
          children: <Widget>[
            Container(
              padding: const EdgeInsets.all(20),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  const CircleAvatar(
                    backgroundImage: AssetImage('assets/images/profile.png'),
                    radius: 40,
                  ),
                  const SizedBox(width: 20),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: const <Widget>[
                      Text(
                        'Susan Arthur',
                        style: TextStyle(
                          fontSize: 18,
                          color: Colors.white,
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      //SizedBox(height: 5),
                      Text(
                        'susan@gmail.com',
                        style: TextStyle(
                          fontSize: 14,
                          color: Colors.white,
                          fontFamily: 'Poppins',
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            Container(
              height: MediaQuery.of(context).size.height - 230,
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(30),
                  topRight: Radius.circular(30),
                ),
              ),
                child: Padding(
                  padding: const EdgeInsets.all(8),
                  child: Column(
                    children: [
                      ListTile(
                        leading: const Icon(Icons.edit),
                        title: const Text('Edit Profile', style: TextStyle(fontFamily: 'Poppins', fontSize: 14),),
                        //trailing: const Icon(Icons.arrow_forward_ios_rounded),
                        onTap: () {
                          // Navigate to edit profile page
                        },
                      ),
                      const Divider(height: 1, thickness: 1,),
                      ListTile(
                        leading: const Icon(Icons.favorite),
                        title: const Text('Favourite Location', style: TextStyle(fontFamily: 'Poppins', fontSize: 14)),
                        //trailing: const Icon(Icons.arrow_forward_ios_rounded),
                        onTap: () {
                          // Navigate to transaction history page
                        },
                      ),
                      const Divider(height: 1, thickness: 1,),
                      ListTile(
                        leading: const Icon(Icons.workspace_premium_rounded),
                        title: const Text('Premium', style: TextStyle(fontFamily: 'Poppins', fontSize: 14)),
                        //trailing: const Icon(Icons.arrow_forward_ios_rounded),
                        onTap: () {
                          // Navigate to reward history page
                        },
                      ),
                      const Divider(height: 1, thickness: 1,),
                      ListTile(
                        leading: const Icon(Icons.settings),
                        title: const Text('Settings', style: TextStyle(fontFamily: 'Poppins', fontSize: 14)),
                        //trailing: const Icon(Icons.arrow_forward_ios_rounded),
                        onTap: () {
                          // Navigate to reward history page
                        },
                      ),
                      const Divider(height: 1, thickness: 1,),
                      ListTile(
                        leading: const Icon(Icons.logout, color: Colors.red,),
                        title: const Text('Log Out', style: TextStyle(color: Colors.red, fontFamily: 'Poppins', fontSize: 14)
                        ),
                        onTap: () {
                          Navigator.push(context, MaterialPageRoute(builder: (context) => const HomePage()),);
                        },
                      ),
                    ],
                  ),
                ),
              ),

          ],
        ),
      ),
    );
  }
}
