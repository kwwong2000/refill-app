import 'package:flutter/material.dart';

class RegisterPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: Text(
            'Registration',
            style: TextStyle(
              fontWeight: FontWeight.w800,
              fontSize: 18.0,
              fontFamily: 'Poppins',
              color : Colors.white,
            ),
          ),
          backgroundColor: Color(0XFF50c2c8)
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              Center(child: Text('Create Your Account',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, fontFamily: 'Poppins'),)),
              SizedBox(height: 32.0),
              Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(30.0),
                  color: Colors.white,
                ),
                child: TextField(
                  decoration: InputDecoration(
                    hintText: 'Name',
                    hintStyle: TextStyle(fontFamily: 'Poppins',),
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Color(0XFF50c2c8)), //<-- SEE HERE
                    ),
                    contentPadding: EdgeInsets.symmetric(horizontal: 16.0),
                  ),
                ),
              ),
              SizedBox(height: 16.0),
              Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(30.0),
                  color: Colors.white,
                ),
                child: TextField(
                  decoration: InputDecoration(
                    hintText: 'Email Address',
                    hintStyle: TextStyle(fontFamily: 'Poppins',),
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Color(0XFF50c2c8)), //<-- SEE HERE
                    ),
                    contentPadding: EdgeInsets.symmetric(horizontal: 16.0),
                  ),
                ),
              ),
              SizedBox(height: 16.0),
              Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(30.0),
                  color: Colors.white,
                ),
                child: TextField(
                  decoration: InputDecoration(
                    hintText: 'Password',
                    hintStyle: TextStyle(fontFamily: 'Poppins',),
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Color(0XFF50c2c8)), //<-- SEE HERE
                    ),
                    contentPadding: EdgeInsets.symmetric(horizontal: 16.0),
                  ),
                ),
              ),
              SizedBox(height: 32.0),
              ElevatedButton(
                child: Text(
                  'Register',
                  style: TextStyle(
                    fontFamily: 'Poppins',
                    fontWeight: FontWeight.bold,
                  )
                ),
                onPressed: () {
                  // TODO: Implement register logic
                },
                style: ElevatedButton.styleFrom(
                  primary: Color(0XFF50c2c8),
                  onPrimary: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30.0),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
