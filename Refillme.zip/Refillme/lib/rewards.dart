import 'package:flutter/material.dart';

class Rewards extends StatelessWidget {
  const Rewards({super.key});

  @override
  Widget build(BuildContext context){

    return Scaffold(
      backgroundColor: Colors.grey.shade100,

      appBar: AppBar(
        backgroundColor: const Color(0XFF50c2c8),
        title: const Text(
          "Rewards",
          style: TextStyle(
            fontWeight: FontWeight.w800,
            fontSize: 18.0,
            color : Colors.white,
            fontFamily: 'Poppins',
          ),),
      ),

      body: Center(
        child: ListView(
          //shrinkWrap: true,
          padding: const EdgeInsets.all(10),
          children: <Widget>[
            Column(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: const [
                SizedBox(height: 20),
                Text(
                  'Points Balance:',
                  style: TextStyle(
                    fontFamily: 'Poppins',
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                  ),
                ),
                Text(
                  '250',
                  style: TextStyle(
                    fontFamily: 'Poppins',
                    fontWeight: FontWeight.w900,
                    fontSize: 32,
                    color: Color(0XFF50c2c8),
                  ),
                ),

                SizedBox(height: 20),

                Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    'Vouchers',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 18,
                    ),
                  ),
                ),

                SizedBox(height: 10),

                reward1(),
                SizedBox(height: 10),
                reward2(),
                SizedBox(height: 10),
                reward3(),

              ],
            ),
          ],
        ),

      ),
    );
  }
}

class reward1 extends StatelessWidget{
  const reward1({super.key});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      title: const Text(
        '15% off up to 3 containers',
        style: TextStyle(
          fontFamily: 'Poppins',
          fontWeight: FontWeight.bold,
          fontSize: 16,
        ),
      ),
      subtitle: const Text(
        '100 points',
        style: TextStyle(
          fontFamily: 'Poppins',
          fontSize: 12,
        ),
      ),
      trailing: ElevatedButton(
        onPressed: () {},
        style: ElevatedButton.styleFrom(
          foregroundColor: const Color(0XFF50c2c8),
          backgroundColor: Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20.0),
            side: const BorderSide(color: Color(0XFF50c2c8), width: 2,),
          ),
        ),
        child: const Text(
          'Redeem',
          style: TextStyle(
            fontFamily: 'Poppins',
            fontWeight: FontWeight.bold,
            fontSize: 12,
          ),
        ),
      ),
      tileColor: const Color(0XFFc1e0cf),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10),
      ),
    );
  }
}

class reward2 extends StatelessWidget{
  const reward2({super.key});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      title: const Text(
        'RM5 off with min spend of RM10',
        style: TextStyle(
          fontFamily: 'Poppins',
          fontWeight: FontWeight.bold,
          fontSize: 16,
        ),
      ),
      subtitle: const Text(
        '150 points',
        style: TextStyle(
          fontFamily: 'Poppins',
          fontSize: 12,
        ),
      ),
      trailing: ElevatedButton(
        onPressed: () {},
        style: ElevatedButton.styleFrom(
          foregroundColor: const Color(0XFF50c2c8),
          backgroundColor: Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20.0),
            side: const BorderSide(color: Color(0XFF50c2c8), width: 2,),
          ),
        ),
        child: const Text(
          'Redeem',
          style: TextStyle(
            fontFamily: 'Poppins',
            fontWeight: FontWeight.bold,
            fontSize: 12,
          ),
        ),
      ),
      tileColor: Color(0XFFc1e0cf),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10),
      ),
    );
  }
}

class reward3 extends StatelessWidget{
  const reward3({super.key});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      title: const Text(
        '15% off up to 5 containers',
        style: TextStyle(
          fontFamily: 'Poppins',
          fontWeight: FontWeight.bold,
          fontSize: 16,
        ),
      ),
      subtitle: const Text(
        '80 points',
        style: TextStyle(
          fontFamily: 'Poppins',
          fontSize: 12,
        ),
      ),
      trailing: ElevatedButton(
        onPressed: () {},
        style: ElevatedButton.styleFrom(
          foregroundColor: const Color(0XFF50c2c8),
          backgroundColor: Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20.0),
            side: const BorderSide(color: Color(0XFF50c2c8), width: 2,),
          ),
        ),
        child: const Text(
          'Redeem',
          style: TextStyle(
            fontFamily: 'Poppins',
            fontWeight: FontWeight.bold,
            fontSize: 12,
          ),
        ),
      ),
      tileColor: Color(0XFFc1e0cf),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10),
      ),
    );
  }
}
