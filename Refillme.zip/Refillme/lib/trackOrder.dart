import 'package:flutter/material.dart';
import 'package:refillme/orderDetails.dart';

class ordersPage extends StatelessWidget {
  final List ordersList = [
    OrdersItem(
      title: 'Order #90897',
      description: 'Placed on 14 March 2023',
      status: 'In Progress',
      item: '5',
      total: 'RM 36.90',
      color: Colors.yellow,
    ),
    OrdersItem(
      title: 'Order #50445',
      description: 'Placed on 9 February 2023',
      status: 'Delivered',
      item: '3',
      total: 'RM 13.50',
      color: Colors.green,
    ),
    OrdersItem(
      title: 'Order #40353',
      description: 'Placed on 1 February 2023',
      status: 'Delivered',
      item: '8',
      total: 'RM 53.10',
      color: Colors.green,
    ),
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Track Order',
          style: TextStyle(
            fontWeight: FontWeight.w800,
            fontSize: 18.0,
            fontFamily: 'Poppins',
            color : Colors.white,
          ),
        ),
        backgroundColor: Color(0XFF50c2c8),
      ),
      backgroundColor: Color(0XFFF4F5F9),
      body: 
      ListView.builder(
        itemCount: ordersList.length,
        itemBuilder: (context, index) {
          return InkWell(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => detailsPage()),
              );
            },
              child: Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(10.0),
            ),
            margin: EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
            child: ListTile(
              title: Text(
                ordersList[index].title,
                style: TextStyle(
                  fontWeight: FontWeight.bold,fontFamily: 'Poppins'
                ),
              ),
              subtitle: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children:[
                  SizedBox(height: 5),
                  Text(
                    ordersList[index].description,
                    style: TextStyle(
                      color: Colors.grey,fontFamily: 'Poppins'
                    ),
                  ),
                  SizedBox(height: 5),
                  Row(
                    children: [
                      Text(
                        'Items: ' + ordersList[index].item,
                        style: TextStyle(
                          color: Colors.black,fontFamily: 'Poppins'
                        ),
                      ),
                      SizedBox(width: 20),
                      Text(
                        'Total: ' + ordersList[index].total,
                        style: TextStyle(
                          color: Colors.black,fontFamily: 'Poppins'
                        ),
                      ),
                    ],
                  ),
                ],
              ),
              trailing: Container(
                width: 95,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: ordersList[index].color),
                ),
                child: Padding(
                  padding: EdgeInsets.all(8.0),
                  child: Text(
                    ordersList[index].status,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: ordersList[index].color,
                      fontFamily: 'Poppins',
                    ),
                  ),
                ),
              ),
            ),

          ),
          );
        },
      ),
    );
  }
}

class OrdersItem {
  final String title;
  final String description;
  final String status;
  final String item;
  final String total;
  final Color color;

  OrdersItem({required this.title, required this.description,
    required this.status,required this.item,required this.total,
    required this.color
  });
}
